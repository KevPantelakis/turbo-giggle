#!/bin/sh

${abs_top_srcdir}/lexique/lexique < ${abs_top_srcdir}/lexique/text-small
