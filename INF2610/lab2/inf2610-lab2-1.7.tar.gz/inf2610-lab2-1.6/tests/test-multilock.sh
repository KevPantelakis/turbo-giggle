#!/bin/sh

${abs_top_srcdir}/multilock/multilock --check
